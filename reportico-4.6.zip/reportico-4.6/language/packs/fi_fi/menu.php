<?php
$locale_arr = array (
    "language" => "Finnish",
    "template" => array (
        "T_CHOOSE_LANGUAGE" => "Valitse kieli",
        "T_GO" => "Suorita",
        "T_LOGGED_IN_AS" => "Kirjautuneena",
        "T_LOGIN" => "Kirjaudu",
        "T_LOGOFF" => "Kirjaudu ulos",
        "T_ADMIN_HOME" => "Ylläpito",
        "T_CONFIG_PROJECT" => "Projektin asetukset",
        "T_CREATE_REPORT" => "Luo raportti",
        "T_ENTER_PROJECT_PASSWORD" => "Anna projektin salasana.",
        "T_ENTER_PROJECT_PASSWORD_DEMO" => "Anna projektin salasana. <br>Opetusohjelmien salasana on <b>reportico</b>",
        "T_UNABLE_TO_CONTINUE" => "toimintoa ei voida jatkaa",
        "T_PASSWORD_ERROR" => "Virheellinen salasana. Yritä uudelleen.",
        ),
    );
?>
