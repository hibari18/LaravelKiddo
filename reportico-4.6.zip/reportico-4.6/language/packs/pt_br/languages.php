<?php

$locale_arr = array (
    "template" => array (
        "T_en_gb" => "Inglês (UK)",
        "T_en_us" => "Inglês (US)",
        "T_es_es" => "Espanhol",
        "T_fr_fr" => "Francês",
        "T_it_it" => "Italiano",
        "T_fi_fi" => "Finlandês",
        "T_ar_ar" => "Árabe",
        "T_zh_cn" => "Chinês",
		"T_pt_br" => "Português Brasileiro",
        ),
    );

?>
