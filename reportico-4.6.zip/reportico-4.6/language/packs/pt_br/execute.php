<?php
$locale_arr = array (
"language" => "Português Brasileiro",
"template" => array (
        // Maintenance Buttons
		"T_GO_PRINT" => "Imprimir",
		"T_GO_BACK" => "Voltar",
		"T_GO_REFRESH" => "Atualizar",
		"T_NO_DATA_FOUND" => "Nenhum dado foi encontrado com os criterios informados",
		"T_UNABLE_TO_CONTINUE" => "Não e possível continuar",
		"T_INFORMATION" => "Informacoes",
        "T_NOTICE" => "Notificação",
        "T_REQUIRED_CRITERIA" => "Você deve fornecer um valor para o item de critérios",
        )
);
?>
