<?php
$locale_arr = array (
"language" => "French",
"template" => array (
        "T_CHOOSE_LANGUAGE" => "Choisir la langue",
        "T_GO" => "Confirmer",
		"T_LOGGED_IN_AS" => "Connecté en tant que",
		"T_LOGIN" => "Connexion",
		"T_LOGOFF" => "Déconnexion",
		"T_ADMIN_HOME" => "Page d'accueil d'administration",
		"T_CONFIG_PROJECT" => "Configurer projet",
		"T_CREATE_REPORT" => "Créer un rapport",
		"T_ENTER_PROJECT_PASSWORD" => "Entrez le mot de passe projet .",
		"T_ENTER_PROJECT_PASSWORD_DEMO" => "Entrez le mot de passe projet. <br>Le mot de passe pour ces tutoriels est <b>reportico</b>",
		"T_UNABLE_TO_CONTINUE" => "Impossible de continuer",
        "T_PASSWORD_ERROR" => "Mot de passe incorrect. Essayez à nouveau .",
    ),
);
?>
