<?php
$locale_arr = array (
"language" => "English",
"template" => array (
        // Maintenance Buttons
		"T_GO_PRINT" => "Print",
		"T_GO_BACK" => "Return",
		"T_GO_REFRESH" => "Refresh",
		"T_NO_DATA_FOUND" => "No data was found matching your criteria",
		"T_REQUIRED_CRITERIA" => "You must provide a value for criteria item ",
		"T_UNABLE_TO_CONTINUE" => "Unable To Continue",
		"T_INFORMATION" => "Information",
		"T_NOTICE" => "Notice",
        )
);
?>
